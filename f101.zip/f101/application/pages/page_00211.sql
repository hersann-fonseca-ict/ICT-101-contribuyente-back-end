prompt --application/pages/page_00211
begin
--   Manifest
--     PAGE: 00211
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>211
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'211-Reporte inscripcion Funcionarios'
,p_alias=>'211-REPORTE-INSCRIPCION-FUNCIONARIOS'
,p_step_title=>'Funcionarios / Ex Funcionarios'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240131160123'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(98378373310033422)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33769151369123641)
,p_plug_name=>'Reporte inscripcion Funcionarios'
,p_parent_plug_id=>wwv_flow_api.id(98378373310033422)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CONTRIBUYENTE,',
'       ID_DEUDOR,',
'       CODIGO_FUENTE, ',
'       NOMBRE_ENTIDAD,',
'       ID_TIPO_CONTRIBUYENTE,',
'       OFICIO,',
'       MOTIVO,',
'       CODIGO_EMPLEADO,',
'       ID_EMPLEADO,',
'       CODIGO_ESTADO',
'  from MAESTRO_CONTRIBUYENTE',
'  where ID_TIPO_CONTRIBUYENTE = 10',
'  order by id_contribuyente desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte inscripcion Funcionarios'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(33769561338123641)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:PDF'
,p_detail_link=>'f?p=&APP_ID.:212:&SESSION.::&DEBUG.:RP,:P212_ID_CONTRIBUYENTE,P212_CODIGO_EMPLEADO:\#ID_CONTRIBUYENTE#\,#CODIGO_EMPLEADO#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>33769561338123641
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33769676675123641)
,p_db_column_name=>'ID_CONTRIBUYENTE'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Id Contribuyente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37695396357585517)
,p_db_column_name=>'CODIGO_FUENTE'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'Codigo Fuente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37695256088585516)
,p_db_column_name=>'ID_DEUDOR'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>unistr('C\00F3digo Tributario')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20454705400931702)
,p_db_column_name=>'CODIGO_EMPLEADO'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>unistr('C\00F3digo Empleado')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20454849580931703)
,p_db_column_name=>'NOMBRE_ENTIDAD'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Nombre Funcionario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(98377412585033413)
,p_db_column_name=>'CODIGO_ESTADO'
,p_display_order=>70
,p_column_identifier=>'L'
,p_column_label=>unistr('C\00F3digo Estado')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(15602871107195194)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33772845395123642)
,p_db_column_name=>'ID_EMPLEADO'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Tipo Empleado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33772077809123642)
,p_db_column_name=>'OFICIO'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Oficio'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33772456599123642)
,p_db_column_name=>'MOTIVO'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20454920956931704)
,p_db_column_name=>'ID_TIPO_CONTRIBUYENTE'
,p_display_order=>110
,p_column_identifier=>'P'
,p_column_label=>'Id Tipo Contribuyente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(33775370977126982)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'337754'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_CONTRIBUYENTE:ID_DEUDOR:CODIGO_EMPLEADO:NOMBRE_ENTIDAD:CODIGO_ESTADO:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37925265457042547)
,p_plug_name=>'Funcionarios / Ex Funcionarios'
,p_parent_plug_id=>wwv_flow_api.id(98378373310033422)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Funcionarios / Ex Funcionarios</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33774076741123646)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(33769151369123641)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:212:&SESSION.::&DEBUG.:212'
);
wwv_flow_api.component_end;
end;
/
