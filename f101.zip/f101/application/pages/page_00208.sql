prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>208
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'208-Formulario Maestro Contribuyente'
,p_alias=>'208-FORMULARIO-MAESTRO-CONTRIBUYENTE'
,p_step_title=>'208-Formulario Maestro Contribuyente'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'//Funcion para redireccionar a la pagina 135 y visualizar el archivo del apoderado',
'function Ir_Archivo_apoderado(pIdArchi, pIDApo,pIdContrib,pMostrar) {',
'    var vURL = ''f?p=&APP_ID.:135:&APP_SESSION.::NO:135:P135_ID_ARCHI_APODERA,P135_ID_APODERADO,P135_ID_CONTRIBUYENTE,P135_MOSTRAR_REGION:'' + pIdArchi + '','' + pIDApo+ '','' + pIdContrib+ '','' + pMostrar;',
'    window.open(vURL, "", "width=1000,height=800");',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240411150047'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32636723726319180)
,p_plug_name=>unistr('Actualizar Informaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MAESTRO_CONTRIBUYENTE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080385026718346)
,p_plug_name=>unistr(' Informaci\00F3n General')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080496327718347)
,p_plug_name=>'Domicilio Fiscal'
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>100
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080584568718348)
,p_plug_name=>unistr('Direcci\00F3n para Notificaciones')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>110
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080671872718349)
,p_plug_name=>unistr(' Informaci\00F3n Gerente de la entidad')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>130
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31080741346718350)
,p_plug_name=>unistr('Informaci\00F3n Representante Legal')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>140
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(80358596027983618)
,p_name=>unistr('Informaci\00F3n Representante Legal')
,p_parent_plug_id=>wwv_flow_api.id(31080741346718350)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>170
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_REPRESENTA,',
'       a.ID_CONTRIBUYENTE,',
'       a.NOMBRE_ARCHIVO,',
'       a.NOMBRE_ARCHIVO VER2,',
'       sys.dbms_lob.getlength(A.ARCHIVO_REPRESENTA)VER,',
'       sys.dbms_lob.getlength(A.ARCHIVO_REPRESENTA)DESCARGAR,',
'       a.MIMETYPE,',
'       a.FEC_ACT,',
'       i.NOMBRE_REPRE_LEGAL,',
'       i.CEDULA_REPRE_LEGAL,',
'       i.CORREO_REPRE_LEGAL,',
'       a.CODIGO_ESTADO',
'  from ARCHIVOS_REPRE_LEGAL a, MAESTRO_CONTRIBUYENTE i',
'  where a.ID_CONTRIBUYENTE = i.ID_CONTRIBUYENTE',
'  AND  a.ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P208_ID_CONTRIBUYENTE'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45484379955642896)
,p_query_column_id=>1
,p_column_alias=>'ID_REPRESENTA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45429618814196214)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45485119817642896)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45488389477642898)
,p_query_column_id=>4
,p_column_alias=>'VER2'
,p_column_display_sequence=>9
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P201_ID_REPRESENTA'',''#ID_REPRESENTA#'');javascript:openModal(''PDF''); $("#PDF").trigger("apexrefresh");'
,p_column_linktext=>'#VER2#'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45488753843642899)
,p_query_column_id=>5
,p_column_alias=>'VER'
,p_column_display_sequence=>8
,p_column_heading=>'Ver online'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ARCHI_REPRE_LEGAL_INSCRIP:ARCHIVO_REPRESENTA:ID_REPRESENTA::MIMETYPE:NOMBRE_ARCHIVO:FEC_ACT::inline:Ver:'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45486771017642897)
,p_query_column_id=>6
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ARCHIVOS_REPRE_LEGAL:ARCHIVO_REPRESENTA:ID_REPRESENTA::MIMETYPE:NOMBRE_ARCHIVO:FEC_ACT::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45485928455642897)
,p_query_column_id=>7
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45486344566642897)
,p_query_column_id=>8
,p_column_alias=>'FEC_ACT'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45485501093642897)
,p_query_column_id=>9
,p_column_alias=>'NOMBRE_REPRE_LEGAL'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45487118499642898)
,p_query_column_id=>10
,p_column_alias=>'CEDULA_REPRE_LEGAL'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45487581687642898)
,p_query_column_id=>11
,p_column_alias=>'CORREO_REPRE_LEGAL'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(81334849112146108)
,p_query_column_id=>12
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>13
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45487956461642898)
,p_query_column_id=>13
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>10
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:Ir_Archivo_repre_legal(''#ID_REPRESENTA#'', ''#ID_NUM_INSCRIPCION#'', ''RLIR'');'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32831474582041401)
,p_plug_name=>unistr('Informaci\00F3n Asistente en Tierra en Costa Rica')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 1100px"'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>170
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IVC'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(32832018813041407)
,p_name=>'Tipo de impuestos a declarar'
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1100px"'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TIPO_IMPUESTO,',
'       ID_CONTRIBUYENTE,',
'       NOMBRE_ENCARGADO_IMP,',
'       CEDULA_ENCARGADO_IMP,',
'       CORREO_ENCARGADO_IMP',
'  from IMPUESTO_X_MAESTRO_CONTRIBUYE',
'  where ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32832531059041412)
,p_query_column_id=>1
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>2
,p_column_heading=>'Tipo Impuesto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12636490143437409)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32832211103041409)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32832683538041413)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ENCARGADO_IMP'
,p_column_display_sequence=>3
,p_column_heading=>'Nombre Encargado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32832715209041414)
,p_query_column_id=>4
,p_column_alias=>'CEDULA_ENCARGADO_IMP'
,p_column_display_sequence=>4
,p_column_heading=>'Cedula'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32832842663041415)
,p_query_column_id=>5
,p_column_alias=>'CORREO_ENCARGADO_IMP'
,p_column_display_sequence=>5
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26214646412341536)
,p_query_column_id=>6
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P208_IMPUESTO_1'',''#ID_TIPO_IMPUESTO#'');javascript:$s(''P208_NOMBRE_ENCAR_1'',''#NOMBRE_ENCARGADO_IMP#'');javascript:$s(''P208_CEDULA_ENCAR_1'',''#CEDULA_ENCARGADO_IMP#'');javascript:$s(''P208_CORREO_ENCAR_1'',''#CORREO_ENCARGADO_IMP#'');javascript'
||':openModal(''M_ID_IMPUESTO''); $("#M_ID_IMPUESTO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26214792359341537)
,p_plug_name=>'Actualizar Impuesto'
,p_region_name=>'M_ID_IMPUESTO'
,p_parent_plug_id=>wwv_flow_api.id(32832018813041407)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(6018269855565420)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(32832950521041416)
,p_name=>unistr('Direcci\00F3n Electr\00F3nica')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>120
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CORREO_NOTIFICA,',
'       ID_CONTRIBUYENTE,',
'       CORREO_NOTIFICA',
'  from CORREO_NOTIFICACIONES',
'  WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE',
'  AND   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833293848041419)
,p_query_column_id=>1
,p_column_alias=>'ID_CORREO_NOTIFICA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833335174041420)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833428821041421)
,p_query_column_id=>3
,p_column_alias=>'CORREO_NOTIFICA'
,p_column_display_sequence=>3
,p_column_heading=>'Correos'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10113889448669107)
,p_query_column_id=>4
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>4
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P208_NEW_CORREO'',''#CORREO_NOTIFICA#'');javascript:$s(''P208_ID_CORREO'',''#ID_CORREO_NOTIFICA#'');javascript:openModal(''ID_CORREO''); $("#ID_CORREO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10113378221669102)
,p_plug_name=>'Actualizar Correo'
,p_region_name=>'ID_CORREO'
,p_parent_plug_id=>wwv_flow_api.id(32832950521041416)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(6018269855565420)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(32833026086041417)
,p_name=>unistr('Informaci\00F3n Apoderado')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>150
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1100px"'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_APODERADO,',
'       a.ID_CONTRIBUYENTE,',
'       a.ID_TIPO_APODERADO,',
'       a.NOMBRE_APODERADO,',
'       a.CEDULA_APODERADO,',
'       a.CORREO_APODERADO,',
'       a.ID_TIPO_IMPUESTO,',
'       a.INDICA_AUTORIZO,',
'       a.FECHA_INICIO_AUTORIZA,',
'       a.FECHA_FIN_AUTORIZA,',
'       a.CODIGO_ESTADO,',
'       PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO(a.ID_APODERADO) EXISTE,',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO)',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fa fa-remove''',
'       end as icon_class,       ',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO)',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'       end as color_class,',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO) ',
'           when ''S'' then ''javascript:$s("P208_ID_APODERADO",''||a.ID_APODERADO||'');javascript:openModal("ARCHI_APO"); $("#ARCHI_APO").trigger("apexrefresh");''',
'           when ''N'' then ''#''',
'       end as link',
'  from APODERADOS a',
'  where a.ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE',
'  and   a.ID_TIPO_APODERADO IS NOT NULL'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P208_ID_CONTRIBUYENTE'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833555452041422)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833683084041423)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833743505041424)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_column_heading=>'Tipo Apoderado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12359510863770461)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833835197041425)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32833983567041426)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>'Cedula'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834039052041427)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834162712041428)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834251121041429)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834338884041430)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834454815041431)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>10
,p_column_heading=>'Fecha Fin Autoriza'
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45120271613705745)
,p_query_column_id=>11
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>11
,p_column_heading=>'Codigo Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(83169057702933715)
,p_query_column_id=>12
,p_column_alias=>'EXISTE'
,p_column_display_sequence=>12
,p_column_heading=>'Existe'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE#</spam>',
'</span>'))
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(83169160258933716)
,p_query_column_id=>13
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(83169217256933717)
,p_query_column_id=>14
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(83169386881933718)
,p_query_column_id=>15
,p_column_alias=>'LINK'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(83169427161933719)
,p_query_column_id=>16
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>13
,p_column_heading=>'Archivos'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(32833142412041418)
,p_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>160
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1100px"'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID_APODERADO,',
'       a.ID_CONTRIBUYENTE,',
'       a.ID_TIPO_APODERADO,',
'       a.NOMBRE_APODERADO,',
'       a.CEDULA_APODERADO,',
'       a.CORREO_APODERADO,',
'      -- a.ID_TIPO_IMPUESTO,',
'       a.INDICA_AUTORIZO,',
'       a.FECHA_INICIO_AUTORIZA,',
'       a.FECHA_FIN_AUTORIZA,',
'       a.CODIGO_ESTADO,',
'       PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO(a.ID_APODERADO) EXISTE,',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO)',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fa fa-remove''',
'       end as icon_class,       ',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO)',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'       end as color_class,',
'       case PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_ARCHI_APO (a.ID_APODERADO) ',
'           when ''S'' then ''javascript:$s("P208_ID_APODERADO",''||a.ID_APODERADO||'');javascript:openModal("ARCHI_APO"); $("#ARCHI_APO").trigger("apexrefresh");''',
'           when ''N'' then ''#''',
'       end as link',
'  from APODERADOS a',
'  where a.ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE',
'  and   a.ID_TIPO_APODERADO IS NULL',
'  order by a.INDICA_AUTORIZO'))
,p_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P208_ID_CONTRIBUYENTE'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834509044041432)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834651815041433)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834729212041434)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834887641041435)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32834976034041436)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Cedula'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835011052041437)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>7
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835214916041439)
,p_query_column_id=>7
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>4
,p_column_heading=>'Tipo Apoderado'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Apoderado;A,Aut. Firma Digital;F,Aut. Terceras personas;T'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835371292041440)
,p_query_column_id=>8
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>8
,p_column_heading=>'Inicio Autoriza'
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835433654041441)
,p_query_column_id=>9
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>9
,p_column_heading=>'Fecha Fin Autoriza'
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(45120332238705746)
,p_query_column_id=>10
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>10
,p_column_heading=>'Codigo Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(23282108311586061)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43549951037307728)
,p_query_column_id=>11
,p_column_alias=>'EXISTE'
,p_column_display_sequence=>13
,p_column_heading=>'Tiene archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43549659376307725)
,p_query_column_id=>12
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43549742792307726)
,p_query_column_id=>13
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43549863950307727)
,p_query_column_id=>14
,p_column_alias=>'LINK'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43549530501307724)
,p_query_column_id=>15
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>14
,p_column_heading=>'Archivos'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110612645883197348)
,p_query_column_id=>16
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>12
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.::P242_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(32835598890041442)
,p_name=>unistr('Tel\00E9fonos ')
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1100px"'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TELEFONO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_TELEFONO,',
'       TELEFONO',
'  from TELEFONO_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835681227041443)
,p_query_column_id=>1
,p_column_alias=>'ID_TELEFONO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835731649041444)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835839526041445)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_TELEFONO'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Tipo Tel\00E9fono')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(32939471103224073)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32835978984041446)
,p_query_column_id=>4
,p_column_alias=>'TELEFONO'
,p_column_display_sequence=>4
,p_column_heading=>'Telefono'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(34484888034508204)
,p_name=>'Tipo Ventas'
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6025720942565417)
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1100px"'
,p_display_column=>2
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_VENTAS,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_VENTAS',
'  from VENTAS_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE'))
,p_display_when_condition=>'P208_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34485171378508207)
,p_query_column_id=>1
,p_column_alias=>'ID_VENTAS'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34485861684508214)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34484958126508205)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_VENTAS'
,p_column_display_sequence=>1
,p_column_heading=>'Tipo Ventas'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(12568970446361830)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(81934178475498336)
,p_name=>unistr('Autorizaci\00F3n a Terceros Archivos')
,p_region_name=>'ARCHI_APO'
,p_parent_plug_id=>wwv_flow_api.id(32636723726319180)
,p_template=>wwv_flow_api.id(6018269855565420)
,p_display_sequence=>150
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>1
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.ID_APODERADO,',
'       b.ID_ARCHI_APODERA,',
'       b.NOMBRE_ARCHIVO,',
'       --sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)VER,',
'       --sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'       sys.dbms_lob.getlength(b.ARCHIVO_APODERADO)DESCARGAR,',
'       b.MIMETYPE',
'  from ARCHIVOS_APODERADOS b',
'  WHERE b.ID_APODERADO = :P208_ID_APODERADO',
'  '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P208_ID_APODERADO'
,p_query_row_template=>wwv_flow_api.id(6052064420565405)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(44236621917912803)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(44237084224912804)
,p_query_column_id=>2
,p_column_alias=>'ID_ARCHI_APODERA'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(44237415742912804)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>3
,p_column_heading=>'Nombre Archivo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10115275488669121)
,p_query_column_id=>4
,p_column_alias=>'DESCARGAR'
,p_column_display_sequence=>6
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:ARCHIVOS_APODERADOS:ARCHIVO_APODERADO:ID_ARCHI_APODERA::MIMETYPE:NOMBRE_ARCHIVO:FEC_ACT::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(44238256487912806)
,p_query_column_id=>5
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(44239052850912807)
,p_query_column_id=>6
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>5
,p_column_heading=>'Ver'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:Ir_Archivo_apoderado(''#ID_ARCHI_APODERA#'', ''#ID_APODERADO#'', ''&P201_ID_NUM_INSCRIPCION.'', ''AIR'');'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26215526135341545)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(26214792359341537)
,p_button_name=>'BTN_GUARDAR_IMP_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32696223228319233)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(32636723726319180)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P208_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32695081014319228)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(32636723726319180)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32696689023319233)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(32636723726319180)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P208_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32695869924319232)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(32636723726319180)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10113725872669106)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10113378221669102)
,p_button_name=>'BTN_GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087817714565383)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(32696950602319233)
,p_branch_name=>'Go To Page 207'
,p_branch_action=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'NEVER'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10113477615669103)
,p_name=>'P208_ID_CORREO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10113378221669102)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10113548221669104)
,p_name=>'P208_NEW_CORREO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10113378221669102)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6086783677565386)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10115081483669119)
,p_name=>'P208_DIRECCION_ENTIDAD_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1000
,p_cHeight=>4
,p_display_when=>'P208_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20455047218931705)
,p_name=>'P208_ENCARGADO_RESPONSABLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Encargado Declaraci\00F3n Informativa :')
,p_source=>'RESPONSABLE_TRIBUTARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26214847994341538)
,p_name=>'P208_IMPUESTO_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(26214792359341537)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P208_ID_TIPO_CONTRIBUYENTE   ',
'--AND   ID_IMPUESTO = :P112_ID_IMPUESTO',
'AND   ID_TIPO_IMPUESTO IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE',
'                            AND CODIGO_ESTADO = ''AC'')  '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086669227565386)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26214934887341539)
,p_name=>'P208_NOMBRE_ENCAR_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(26214792359341537)
,p_prompt=>'Nombre Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086984988565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26215132122341541)
,p_name=>'P208_CEDULA_ENCAR_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(26214792359341537)
,p_prompt=>unistr('C\00E9dula Encargado:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086984988565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26215308660341543)
,p_name=>'P208_CORREO_ENCAR_1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(26214792359341537)
,p_prompt=>'Correo Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(6086984988565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32637190574319185)
,p_name=>'P208_ID_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'ID_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32637553469319191)
,p_name=>'P208_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Nombre Entidad:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32637910413319195)
,p_name=>'P208_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32638328368319195)
,p_name=>'P208_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>80
,p_colspan=>6
,p_display_when=>'P208_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32638799198319196)
,p_name=>'P208_PERSONA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Persona F\00EDsica:')
,p_source=>'PERSONA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_colspan=>5
,p_display_when=>'P208_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'2'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32639169156319196)
,p_name=>'P208_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Documento de identidad:'
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P208_CEDULA_JURIDICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32639549947319198)
,p_name=>'P208_CEDULA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Documento de identidad:'
,p_source=>'CEDULA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P208_CEDULA_FISICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32639999622319198)
,p_name=>'P208_ID_TIPO_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Tipo Contribuyente:'
,p_source=>'ID_TIPO_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CONTRIBUYENTE_IR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_TIPO_CONTRIBUYENTE, DESCRIPCION',
'FROM TIPO_CONTRIBUYENTE',
'WHERE CODIGO_ESTADO = ''AC''',
'--AND   IND_TIPO_INSCRIP = ''IR'''))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32640361429319198)
,p_name=>'P208_CODIGO_IATA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('C\00F3digo IATA:')
,p_source=>'CODIGO_IATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>23
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_display_when=>'P208_MUESTRA_IATA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32641140916319198)
,p_name=>'P208_FECHA_INICIO_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Inicio Operaciones:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INICIO_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32641577660319198)
,p_name=>'P208_DIRECCION_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(31080496327718347)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32641936466319200)
,p_name=>'P208_ID_PROVINCIA_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(31080496327718347)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32642365037319200)
,p_name=>'P208_ID_CANTON_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(31080496327718347)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P208_ID_PROVINCIA_ENTIDAD'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32642700798319200)
,p_name=>'P208_ID_DISTRITO_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(31080496327718347)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P208_ID_PROVINCIA_ENTIDAD',
'AND CANTON_ID = :P208_ID_CANTON_ENTIDAD'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32643178447319200)
,p_name=>'P208_DIRECCION_NOTIFICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(31080584568718348)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>800
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32643571985319200)
,p_name=>'P208_ID_PROVINCIA_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(31080584568718348)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32643939034319201)
,p_name=>'P208_ID_CANTON_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(31080584568718348)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P208_ID_PROVINCIA_NOTIFICA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32644329239319201)
,p_name=>'P208_ID_DISTRITO_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(31080584568718348)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P208_ID_PROVINCIA_NOTIFICA',
'AND CANTON_ID = :P208_ID_CANTON_NOTIFICA'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32644729287319202)
,p_name=>'P208_CEDULA_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31080671872718349)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Cedula:'
,p_source=>'CEDULA_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32645193725319202)
,p_name=>'P208_NOMBRE_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31080671872718349)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32645536673319202)
,p_name=>'P208_CORREO_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(31080671872718349)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Correo:'
,p_source=>'CORREO_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32645910084319202)
,p_name=>'P208_NOMBRE_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(31080741346718350)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32646352930319203)
,p_name=>'P208_CEDULA_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(31080741346718350)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Cedula:'
,p_source=>'CEDULA_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32646767176319203)
,p_name=>'P208_CORREO_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(31080741346718350)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Correo:'
,p_source=>'CORREO_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32647118864319203)
,p_name=>'P208_CODIGO_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Estado:'
,p_source=>'CODIGO_ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT  NOMBRE_ESTADO,CODIGO_ESTADO FROM estados_tramite@consulta_ictx where CODIGO_ESTADO IN (''AC'',''IA'')'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32647515866319203)
,p_name=>'P208_FECHA_INSCRIPCION'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('Fecha Inscripci\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32647926414319203)
,p_name=>'P208_FECHA_CESE_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Cese Operaciones:'
,p_source=>'FECHA_CESE_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'P208_CODIGO_ESTADO'
,p_display_when2=>'IA'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32648342868319204)
,p_name=>'P208_FECHA_INICIO_VENTAS'
,p_source_data_type=>'DATE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'FECHA_INICIO_VENTAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32648759301319204)
,p_name=>'P208_OBSERVA_EMPRESA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'OBSERVA_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32649194648319204)
,p_name=>'P208_OBSERVA_ADM_TRIBUTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'OBSERVA_ADM_TRIBUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32649521561319204)
,p_name=>'P208_ID_MODALIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Modalidad:'
,p_source=>'ID_MODALIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_MODALIDAD'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_display_when=>'P208_TIPO_INSCRIPCION'
,p_display_when2=>'IR'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32649981039319204)
,p_name=>'P208_CODIGO_FUENTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'CODIGO_FUENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32651519475319206)
,p_name=>'P208_FECHA_SUSCRITO'
,p_source_data_type=>'DATE'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'FECHA_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32651941357319206)
,p_name=>'P208_LUGAR_SUSCRITO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'LUGAR_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32658327776319209)
,p_name=>'P208_ID_NUM_INSCRIPCION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_source=>'ID_NUM_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32658701123319209)
,p_name=>'P208_NOM_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(32831474582041401)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Nombre:'
,p_source=>'NOM_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32659194291319209)
,p_name=>'P208_CEDULA_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>560
,p_item_plug_id=>wwv_flow_api.id(32831474582041401)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Cedula:'
,p_source=>'CEDULA_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32659552601319209)
,p_name=>'P208_CORREO_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_api.id(32831474582041401)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>'Correo:'
,p_source=>'CORREO_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>40
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32831614828041403)
,p_name=>'P208_TIPO_INSCRIPCION'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(32636723726319180)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32836022115041447)
,p_name=>'P208_CONTRIBUYENTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_prompt=>'Id Contribuyente:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36612888928747516)
,p_name=>'P208_PERIODO_INI_INACTIVO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_prompt=>unistr('Inicio Inactivaci\00F3n: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_display_when=>'P208_CODIGO_ESTADO'
,p_display_when2=>'IA'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36612944107747517)
,p_name=>'P208_PERIODO_FIN_INACTIVO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_prompt=>unistr('Fin Inactivaci\00F3n: ')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'P208_CODIGO_ESTADO'
,p_display_when2=>'IA'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37064158472503234)
,p_name=>'P208_ESTADOS'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(38648115686961121)
,p_name=>'P208_USUARIO_SIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_item_default=>':APP_USER'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Usuario:'
,p_source=>'USUARIO_SIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(44239487671912810)
,p_name=>'P208_ID_APODERADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(81934178475498336)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(83170715736933732)
,p_name=>'P208_MUESTRA_IATA'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(83170939733933734)
,p_name=>'P208_ID_DEUDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(31080385026718346)
,p_item_source_plug_id=>wwv_flow_api.id(32636723726319180)
,p_prompt=>unistr('C\00F3digo Tributario:')
,p_source=>'ID_DEUDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6086522936565386)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(26215076396341540)
,p_validation_name=>'VAL_NOM_ENCAR_1'
,p_validation_sequence=>10
,p_validation=>'P208_NOMBRE_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el nombre del encargado del impuesto.'
,p_validation_condition=>'P208_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26214934887341539)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(26215285509341542)
,p_validation_name=>'VAL_CEDULA_ENCAR_1'
,p_validation_sequence=>20
,p_validation=>'P208_CEDULA_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar la cedula del encargado del impuesto.'
,p_validation_condition=>'P208_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26215132122341541)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(26215476852341544)
,p_validation_name=>'VAL_CORREO_ENCAR_1'
,p_validation_sequence=>30
,p_validation=>'P208_CORREO_ENCAR_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el correo del encargado del impuesto.'
,p_validation_condition=>'P208_IMPUESTO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26215308660341543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27638246153385601)
,p_validation_name=>'VAL_FORMATO_EMAIL'
,p_validation_sequence=>40
,p_validation=>'P208_CORREO_ENCAR_1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P208_CORREO_ENCAR_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26215308660341543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27638303991385602)
,p_validation_name=>'VAL_COMAS'
,p_validation_sequence=>50
,p_validation=>'P208_CORREO_ENCAR_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_validation_condition=>'P208_CORREO_ENCAR_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26215308660341543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(27638404981385603)
,p_validation_name=>'VAL_PUNTOS'
,p_validation_sequence=>60
,p_validation=>'P208_CORREO_ENCAR_1'
,p_validation2=>'.'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P208_CORREO_ENCAR_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(26215308660341543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(37922166646042516)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT/INAC_CONTRIB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno VARCHAR2(200);',
'vRetorno boolean;',
'vCedula VARCHAR2(20);',
'BEGIN',
'IF :P208_CODIGO_ESTADO <> ''AC'' THEN',
'        --Se activa el usuario ',
'    UPDATE USUARIOS_EXTERNOS SET CODIGO_ESTADO = ''IA'' WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'    --El estado del contribuyente se cambia activo',
'    --UPDATE MAESTRO_CONTRIBUYENTE SET CODIGO_ESTADO = ''IA'' WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'     --Se inserta el periodo de inactivacion ',
'    PKG_MAESTRO_CONTRIBUYENTE.INSERTA_PERIODO_INACTIVACION (:P208_ID_CONTRIBUYENTE,:APP_USER,''I'');',
'    --Inactivar en maestro_deudores',
'    UPDATE MAESTRO_DEUDORES@CONSULTA_ICTX SET CODIGO_ESTADO = ''AI'' WHERE ID_DEUDOR = :P208_ID_DEUDOR;',
'END IF;',
'IF  :P208_CODIGO_ESTADO <> ''IA'' THEN',
'    --El estado del contribuyente se cambia a activo',
'    --UPDATE MAESTRO_CONTRIBUYENTE SET CODIGO_ESTADO = ''AC'' WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'    --Se activa el usuario ',
'    UPDATE USUARIOS_EXTERNOS SET CODIGO_ESTADO = ''AC'' WHERE ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
unistr('    --Se genera una contrase\00F1a temporal y se envia un correo con esa contrase\00F1a temporal'),
'        IF :P208_CEDULA_JURIDICA IS NOT NULL THEN',
'            vCedula := :P208_CEDULA_JURIDICA;',
'        ELSIF :P208_CEDULA_FISICA IS NOT NULL THEN',
'        vCedula := :P208_CEDULA_FISICA;',
'        END IF;',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIF_ACTIVACION_USR (vCedula,8,''A'',:APP_USER,vMensaje_Retorno,vRetorno);',
'    --Se inserta el periodo de inactivacion ',
'    PKG_MAESTRO_CONTRIBUYENTE.INSERTA_PERIODO_INACTIVACION (:P208_ID_CONTRIBUYENTE,:APP_USER,''A'');',
'    --Activar en maestro_deudores',
'    UPDATE MAESTRO_DEUDORES@CONSULTA_ICTX SET CODIGO_ESTADO = ''AC'' WHERE ID_DEUDOR = :P208_ID_DEUDOR;',
'',
'END IF;',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(32696223228319233)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(32697855950319237)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(32636723726319180)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 208-Formulario Maestro Contribuyente'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(32697420937319235)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(32636723726319180)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 208-Formulario Maestro Contribuyente'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(32831953547041406)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vTipoIncrip VARCHAR2(4);',
'vInicioInactivacion DATE;',
'vFinInactivacion DATE;',
'',
'    CURSOR C_TIP_INSCRIP IS',
'    SELECT IND_TIPO_INSCRIP',
'    FROM   TIPO_CONTRIBUYENTE',
'    WHERE  ID_TIPO_CONTRIBUYENTE = :P208_ID_TIPO_CONTRIBUYENTE;',
'    ',
'    CURSOR C_PER_INAC_CONTRIB IS',
'    SELECT PERIODO_INI_INACTIVO,PERIODO_FIN_INACTIVO',
'    FROM   PERIODOS_INACTIVO_CONTRI',
'    WHERE  ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'BEGIN',
'    OPEN  C_TIP_INSCRIP;',
'    FETCH C_TIP_INSCRIP INTO vTipoIncrip;',
'    CLOSE C_TIP_INSCRIP;',
'    ',
'    OPEN  C_PER_INAC_CONTRIB;',
'    FETCH C_PER_INAC_CONTRIB INTO vInicioInactivacion,vFinInactivacion;',
'    CLOSE C_PER_INAC_CONTRIB;',
'    ',
'    :P208_CONTRIBUYENTE    := :P208_ID_CONTRIBUYENTE;',
'    :P208_TIPO_INSCRIPCION := vTipoIncrip;',
'    ',
'    IF :P208_CODIGO_ESTADO = ''IA'' THEN',
'    :P208_PERIODO_INI_INACTIVO := vInicioInactivacion;',
'    :P208_PERIODO_FIN_INACTIVO := vFinInactivacion;',
'   END IF;',
'    --IF :P208_TIPO_INSCRIPCION = ''IR'' THEN',
'    :P208_ESTADOS := :P208_CODIGO_ESTADO;',
'   -- END IF;',
'    :P208_USUARIO_SIT := :APP_USER;',
'    ',
'IF :P208_ID_TIPO_CONTRIBUYENTE IN (4,5) THEN',
'    :P208_MUESTRA_IATA := ''N'';',
'    ELSE',
'    :P208_MUESTRA_IATA := ''S'';',
'END IF;',
'    ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10113957039669108)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE CORREO_NOTIFICACIONES SET CORREO_NOTIFICA = :P208_NEW_CORREO,USUARIO_SIT = :APP_USER WHERE ID_CORREO_NOTIFICA = :P208_ID_CORREO AND ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10113725872669106)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(26215708953341547)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Impuesto NUMBER;',
'BEGIN',
'IF :P208_IMPUESTO_1 IS NOT NULL THEN',
'    IF :P208_NOMBRE_ENCAR_1 IS NOT NULL AND :P208_CEDULA_ENCAR_1 IS NOT NULL AND :P208_CORREO_ENCAR_1 IS NOT NULL THEN',
'',
'    UPDATE IMPUESTO_X_MAESTRO_CONTRIBUYE SET --ID_TIPO_IMPUESTO =     :P208_IMPUESTO_1,',
'                                             NOMBRE_ENCARGADO_IMP = :P208_NOMBRE_ENCAR_1,',
'                                             CEDULA_ENCARGADO_IMP = :P208_CEDULA_ENCAR_1,',
'                                             CORREO_ENCARGADO_IMP = :P208_CORREO_ENCAR_1,',
'                                             USUARIO_SIT =          :APP_USER',
'    WHERE  ID_TIPO_IMPUESTO = :P208_IMPUESTO_1 AND                ',
'           ID_CONTRIBUYENTE = :P208_ID_CONTRIBUYENTE;',
'    COMMIT;',
'    /*vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'    INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_IMPUESTO,',
'                                                    :P112_ID_CONTRIBUYENTE,',
'                                                    :P112_NOMBRE_ENCAR,',
'                                                    :P112_CEDULA_ENCAR,',
'                                                    :P112_CORREO_ENCAR,',
'                                                    ''P'',',
'                                                    :APP_USER,',
'                                                    ''N'',',
'                                                   vId_Impuesto);',
'    COMMIT;   ',
'    PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,:P112_ID_DEUDOR,12,''I'',''I'',0);*/',
'--:P112_BRANCH := ''S'';',
'    END IF;',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(26215526135341545)
);
wwv_flow_api.component_end;
end;
/
