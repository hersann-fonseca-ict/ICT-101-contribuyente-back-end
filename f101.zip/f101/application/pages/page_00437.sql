prompt --application/pages/page_00437
begin
--   Manifest
--     PAGE: 00437
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>437
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'437-Bitacora Apoderado mc'
,p_alias=>'437-BITACORA-APODERADO-MC'
,p_step_title=>unistr('Bit\00E1cora Apoderado mc')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221111130313'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41623177798763404)
,p_plug_name=>'437-Bitacora Aut firma digital'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       CODIGO_ESTADO,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'''LINK''LINK',
'  from BITACORA_APODERADOS',
'  where ID_CONTRIBUYENTE = :P437_ID_CONTRIB',
'  and   INDICA_AUTORIZO = ''F'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P437_ID_CONTRIB'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P437_PAGINA'
,p_plug_display_when_cond2=>'415'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'437-Bitacora Aut firma digital'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41623233802763405)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41623233802763405
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623388166763406)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623408372763407)
,p_db_column_name=>'ID_CONTRIBUYENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Contribuyente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623586197763408)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623603378763409)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623743282763410)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623896804763411)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41623910055763412)
,p_db_column_name=>'ID_TIPO_IMPUESTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Impuesto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(12636490143437409)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624058918763413)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624141955763414)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624231202763415)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624340707763416)
,p_db_column_name=>'CODIGO_ESTADO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(23282108311586061)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624447077763417)
,p_db_column_name=>'FECHA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624589885763418)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624692485763419)
,p_db_column_name=>'USUARIO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(111929067855574222)
,p_db_column_name=>'LINK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Bit. Impuestos'
,p_column_link=>'f?p=&APP_ID.:448:&SESSION.::&DEBUG.::P448_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41738881200276200)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'417389'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_APODERADO:ID_CONTRIBUYENTE:ID_TIPO_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:ID_TIPO_IMPUESTO:INDICA_AUTORIZO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:CODIGO_ESTADO:FECHA:ID_TIPO_OPERACION:USUARIO:LINK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41624781632763420)
,p_plug_name=>'437-Bitacora Aut a terceros'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       CODIGO_ESTADO,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'NULL Link_bit_archi_apo,',
'''LINK''LINK',
'  from BITACORA_APODERADOS',
'  where ID_CONTRIBUYENTE = :P437_ID_CONTRIB',
'  and   INDICA_AUTORIZO = ''T'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P437_ID_CONTRIB'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P437_PAGINA'
,p_plug_display_when_cond2=>'415'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'437-Bitacora Aut a terceros'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41624820176763421)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41624820176763421
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41624920866763422)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625089977763423)
,p_db_column_name=>'ID_CONTRIBUYENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Contribuyente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625192401763424)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625207793763425)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625357806763426)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625453245763427)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625560749763428)
,p_db_column_name=>'ID_TIPO_IMPUESTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo Impuesto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(12636490143437409)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625691233763429)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625786380763430)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625853459763431)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41625944323763432)
,p_db_column_name=>'CODIGO_ESTADO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(23282108311586061)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41626096673763433)
,p_db_column_name=>'FECHA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41626158376763434)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41626211522763435)
,p_db_column_name=>'USUARIO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41627458867763447)
,p_db_column_name=>'LINK_BIT_ARCHI_APO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Bit Archivo'
,p_column_link=>'f?p=&APP_ID.:438:&SESSION.::&DEBUG.::P438_ID_APODERADO,P438_PAGINA:#ID_APODERADO#,437'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(111928914708574221)
,p_db_column_name=>'LINK'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bit. Impuestos'
,p_column_link=>'f?p=&APP_ID.:448:&SESSION.::&DEBUG.::P448_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41746013196284643)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'417461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:ID_TIPO_IMPUESTO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:CODIGO_ESTADO:FECHA:ID_TIPO_OPERACION:LINK:LINK_BIT_ARCHI_APO:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41626365398763436)
,p_plug_name=>'Bit aut firma digital'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<center><h3>Bit\00E1cora autorizaci\00F3n firma digital</h3></center>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P437_PAGINA'
,p_plug_display_when_cond2=>'415'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41626721231763440)
,p_plug_name=>'Bit aut terceros'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<center><h3>Bit\00E1cora autorizaci\00F3n a terceros</h3></center>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P437_PAGINA'
,p_plug_display_when_cond2=>'415'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41695394731177115)
,p_plug_name=>'437-Bitacora Apoderado mc'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       CODIGO_ESTADO,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'       NULL Link_bit_archi_apo',
'  from BITACORA_APODERADOS',
'  where ID_CONTRIBUYENTE = :P437_ID_CONTRIB',
'  and   INDICA_AUTORIZO = ''A'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P437_ID_CONTRIB'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'437-Bitacora Apoderado mc'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41695406188177115)
,p_name=>'437-Bitacora Apoderado mc'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41695406188177115
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41695891061177115)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41696296389177115)
,p_db_column_name=>'ID_CONTRIBUYENTE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id Contribuyente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41696682203177116)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(12359510863770461)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41697088256177116)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41697422749177116)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41697824112177116)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41698203742177116)
,p_db_column_name=>'ID_TIPO_IMPUESTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Tipo Impuesto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41698664283177116)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41699053252177117)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41699481485177117)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41699883736177117)
,p_db_column_name=>'CODIGO_ESTADO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(23282108311586061)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41700240082177117)
,p_db_column_name=>'FECHA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41700686782177117)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41701072485177117)
,p_db_column_name=>'USUARIO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41626982138763442)
,p_db_column_name=>'LINK_BIT_ARCHI_APO'
,p_display_order=>24
,p_column_identifier=>'O'
,p_column_label=>'Bit Archivos'
,p_column_link=>'f?p=&APP_ID.:438:&SESSION.::&DEBUG.::P438_ID_APODERADO,P438_PAGINA:#ID_APODERADO#,437'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41729275347258150)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'417293'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_APODERADO:ID_CONTRIBUYENTE:ID_TIPO_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:ID_TIPO_IMPUESTO:INDICA_AUTORIZO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:CODIGO_ESTADO:FECHA:ID_TIPO_OPERACION:USUARIO:LINK_BIT_ARCHI_APO'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(990297455335733892)
,p_plug_name=>'Bit apoderados mc'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Bit\00E1cora apoderados</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41701780577179794)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(990297455335733892)
,p_button_name=>'BTN_REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087175290565385)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Btn Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:&P437_PAGINA.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41702108727179794)
,p_name=>'P437_ID_CONTRIB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(990297455335733892)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41702555275179794)
,p_name=>'P437_PAGINA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(990297455335733892)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
