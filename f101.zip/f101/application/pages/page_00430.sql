prompt --application/pages/page_00430
begin
--   Manifest
--     PAGE: 00430
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>430
,p_user_interface_id=>wwv_flow_api.id(6110350152565363)
,p_name=>'430-Bitacora Apoderados inscripcion regular'
,p_alias=>'430-BITACORA-APODERADOS-INSCRIPCION-REGULAR'
,p_step_title=>unistr('Bit\00E1cora Apoderados inscripci\00F3n regular')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221111094553'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40843944974463637)
,p_plug_name=>unistr('Bit autorizaci\00F3n firma digital')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<center><h3>Bit\00E1cora autorizaci\00F3n firma digital</h3></center>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P430_PAGINA'
,p_plug_display_when_cond2=>'414'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40844085101463638)
,p_plug_name=>unistr('Bit autorizaci\00F3n a terceros')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('<center><h3>Bit\00E1cora autorizaci\00F3n a terceros</h3></center>')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P430_PAGINA'
,p_plug_display_when_cond2=>'414'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40844193939463639)
,p_plug_name=>unistr('430-Bitacora autorizaci\00F3n firma digital')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_TIPO_APODERADO,',
'       ID_NUM_INSCRIPCION,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'       ''LINK''LINK',
'  from BITA_APODERA_SOLICITUD',
'  where ID_NUM_INSCRIPCION = :P430_NUM_INSCRIPCION',
'    and   INDICA_AUTORIZO = ''F'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P430_NUM_INSCRIPCION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P430_PAGINA'
,p_plug_display_when_cond2=>'414'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('430-Bitacora autorizaci\00F3n firma digital')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40844399232463641)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>40844399232463641
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844456039463642)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844567442463643)
,p_db_column_name=>'ID_NUM_INSCRIPCION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Num Inscripcion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844658767463644)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844784632463645)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844812211463646)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40844915639463647)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40845103272463649)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40845282799463650)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41435493026487701)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41435556228487702)
,p_db_column_name=>'FECHA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41435657272487703)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41435741089487704)
,p_db_column_name=>'USUARIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(111928512452574217)
,p_db_column_name=>'LINK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Bit. Impuestos'
,p_column_link=>'f?p=&APP_ID.:447:&SESSION.::&DEBUG.::P447_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41446215352491114)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'414463'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'ID_APODERADO:ID_NUM_INSCRIPCION:ID_TIPO_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:INDICA_AUTORIZO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:FECHA:ID_TIPO_OPERACION:USUARIO:LINK'
,p_sort_column_1=>'ID_APODERADO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'FECHA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41416623273395685)
,p_plug_name=>'430-Bitacora Apoderados inscripcion regular'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_TIPO_APODERADO,',
'       ID_NUM_INSCRIPCION,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'       NULL LINK_BIT_ARCHIVOS',
'  from BITA_APODERA_SOLICITUD',
'  where ID_NUM_INSCRIPCION = :P430_NUM_INSCRIPCION',
'  and   INDICA_AUTORIZO = ''A'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P430_NUM_INSCRIPCION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'430-Bitacora Apoderados inscripcion regular'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41416732020395685)
,p_name=>'430-Bitacora Apoderados inscripcion regular'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41416732020395685
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41417199412395685)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41417581084395686)
,p_db_column_name=>'ID_NUM_INSCRIPCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id Num Inscripcion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41417940845395686)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(12359510863770461)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41418301310395686)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41418706392395686)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41419185650395686)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41419587916395686)
,p_db_column_name=>'ID_TIPO_IMPUESTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Tipo Impuesto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41419917144395687)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41420329745395687)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41420777603395687)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40843606945463634)
,p_db_column_name=>'FECHA'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40843702262463635)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40843814141463636)
,p_db_column_name=>'USUARIO'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437402505487721)
,p_db_column_name=>'LINK_BIT_ARCHIVOS'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>'Bit Archivos'
,p_column_link=>'f?p=&APP_ID.:431:&SESSION.::&DEBUG.::P431_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41422692184407001)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'414227'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'ID_APODERADO:ID_TIPO_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:FECHA:ID_TIPO_OPERACION:USUARIO::LINK_BIT_ARCHIVOS'
,p_sort_column_1=>'ID_APODERADO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'FECHA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41435849625487705)
,p_plug_name=>unistr('430-Bitacora autorizaci\00F3n a terceros')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6023806531565418)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_TIPO_APODERADO,',
'       ID_NUM_INSCRIPCION,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA,',
'       FECHA,',
'       ID_TIPO_OPERACION,',
'       USUARIO,',
'       NULL LINK_BIT_ARCHIVOS,',
'''LINK''LINK',
'  from BITA_APODERA_SOLICITUD',
'  where ID_NUM_INSCRIPCION = :P430_NUM_INSCRIPCION',
'  and   INDICA_AUTORIZO = ''T''',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P430_NUM_INSCRIPCION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P430_PAGINA'
,p_plug_display_when_cond2=>'414'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('430-Bitacora autorizaci\00F3n a terceros')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41436043606487707)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'KIMBERLYN.SOLANO'
,p_internal_uid=>41436043606487707
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436194555487708)
,p_db_column_name=>'ID_APODERADO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436252038487709)
,p_db_column_name=>'ID_NUM_INSCRIPCION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id Num Inscripcion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436384710487710)
,p_db_column_name=>'ID_TIPO_APODERADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo Apoderado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436476763487711)
,p_db_column_name=>'NOMBRE_APODERADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436593191487712)
,p_db_column_name=>'CEDULA_APODERADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436611606487713)
,p_db_column_name=>'CORREO_APODERADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436861745487715)
,p_db_column_name=>'INDICA_AUTORIZO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Indica Autorizo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41436906950487716)
,p_db_column_name=>'FECHA_INICIO_AUTORIZA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Inicio Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437072030487717)
,p_db_column_name=>'FECHA_FIN_AUTORIZA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Fin Autorizaci\00F3n ')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437154080487718)
,p_db_column_name=>'FECHA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Mod.'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437210762487719)
,p_db_column_name=>'ID_TIPO_OPERACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('Tipo Operaci\00F3n')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(31489783213927013)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437358672487720)
,p_db_column_name=>'USUARIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41437650280487723)
,p_db_column_name=>'LINK_BIT_ARCHIVOS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Bit Archivos'
,p_column_link=>'f?p=&APP_ID.:431:&SESSION.::&DEBUG.::P431_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(111928673270574218)
,p_db_column_name=>'LINK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Bit. Impuestos'
,p_column_link=>'f?p=&APP_ID.:447:&SESSION.::&DEBUG.::P447_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41451822778496289)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'414519'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_APODERADO:NOMBRE_APODERADO:CEDULA_APODERADO:CORREO_APODERADO:FECHA_INICIO_AUTORIZA:FECHA_FIN_AUTORIZA:FECHA:ID_TIPO_OPERACION:LINK:LINK_BIT_ARCHIVOS:'
,p_sort_column_1=>'ID_APODERADO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'FECHA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(698979886195439740)
,p_plug_name=>'Bit apoderados inscripcion regular'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6025720942565417)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Bit\00E1cora apoderados</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41437807158487725)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(698979886195439740)
,p_button_name=>'BTN_REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6087175290565385)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Btn Regresar'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:&P430_PAGINA.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40843584337463633)
,p_name=>'P430_NUM_INSCRIPCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(41416623273395685)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41512001437725826)
,p_name=>'P430_PAGINA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(41416623273395685)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
