prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(263870169679029499)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263870374095029499)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Par\00E1metros')
,p_list_item_icon=>'fa-save'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263871185456029500)
,p_list_item_display_sequence=>21
,p_list_item_link_text=>unistr('T\00E9cnico')
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263877948209029503)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sistemas'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263871185456029500)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263878706152029503)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Tipo Movimientos SIT'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263871185456029500)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122,123'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263902320838029516)
,p_list_item_display_sequence=>642
,p_list_item_link_text=>'Tipo modulo'
,p_list_item_link_target=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263871185456029500)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'138,139'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263902735545029516)
,p_list_item_display_sequence=>651
,p_list_item_link_text=>'Roles internos SIT'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263871185456029500)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'136,137'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263871597303029500)
,p_list_item_display_sequence=>22
,p_list_item_link_text=>'Tipo ventas'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263871979911029500)
,p_list_item_display_sequence=>23
,p_list_item_link_text=>unistr('Tipo tel\00E9fono')
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263872318970029500)
,p_list_item_display_sequence=>24
,p_list_item_link_text=>'Tipo requisitos'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263872766701029500)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Tipo modalidad'
,p_list_item_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263873186867029501)
,p_list_item_display_sequence=>26
,p_list_item_link_text=>'Tipo apoderado'
,p_list_item_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263873505612029501)
,p_list_item_display_sequence=>27
,p_list_item_link_text=>unistr('Tipo identificaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263873905987029501)
,p_list_item_display_sequence=>29
,p_list_item_link_text=>'Tipo puesto fronterizo'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263877577466029503)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Tipo Solicitud'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'110,111'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263878306854029503)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Tipo Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'118,119'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263879979642029504)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Tipo Ente'
,p_list_item_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'125,126'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263881592370029505)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Tipo Local'
,p_list_item_link_target=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'127,128'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263883537769029506)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Tipo Empleado'
,p_list_item_link_target=>'f?p=&APP_ID.:129:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'129,130'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263891122564029511)
,p_list_item_display_sequence=>411
,p_list_item_link_text=>'Correos'
,p_list_item_link_target=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'131,132'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263891540874029511)
,p_list_item_display_sequence=>421
,p_list_item_link_text=>'Encargado Correo'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'133,134'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263903149457029516)
,p_list_item_display_sequence=>661
,p_list_item_link_text=>'Tipo Recomendacion'
,p_list_item_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'140,141'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263905573742029518)
,p_list_item_display_sequence=>721
,p_list_item_link_text=>'Tipo Noticia'
,p_list_item_link_target=>'f?p=&APP_ID.:145:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'145,146'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263906354210029518)
,p_list_item_display_sequence=>741
,p_list_item_link_text=>'Noticias Sit'
,p_list_item_link_target=>'f?p=&APP_ID.:147:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'147,148'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263908702520029519)
,p_list_item_display_sequence=>801
,p_list_item_link_text=>'Mant. Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:149:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'149'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263909589806029520)
,p_list_item_display_sequence=>821
,p_list_item_link_text=>'Oficina Regional RN'
,p_list_item_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'151'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263918752574029524)
,p_list_item_display_sequence=>1061
,p_list_item_link_text=>'Tipo Aduanas'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263919119486029524)
,p_list_item_display_sequence=>1071
,p_list_item_link_text=>'Tipo Destinos'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263870737006029499)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Procesos'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263874381988029501)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Hoteles'
,p_list_item_link_target=>'f?p=&APP_ID.:227:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'227,228'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263874756016029501)
,p_list_item_display_sequence=>31
,p_list_item_link_text=>unistr('Inscripci\00F3n Regular')
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263875173157029502)
,p_list_item_display_sequence=>32
,p_list_item_link_text=>unistr('Inscripci\00F3n Regular Pendiente')
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263874756016029501)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200,201'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263875953379029502)
,p_list_item_display_sequence=>34
,p_list_item_link_text=>unistr('Solicitud des-Inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263874756016029501)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263876724017029502)
,p_list_item_display_sequence=>36
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:IR:'
,p_parent_list_item_id=>wwv_flow_api.id(263874756016029501)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263875532968029502)
,p_list_item_display_sequence=>33
,p_list_item_link_text=>unistr('Inscripci\00F3n Vuelos ch\00E1rter')
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'205,206'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263889985164029509)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Inscripciones Pendientes'
,p_list_item_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263875532968029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263892305833029511)
,p_list_item_display_sequence=>441
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:IVC:'
,p_parent_list_item_id=>wwv_flow_api.id(263875532968029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Registro No Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263883145778029505)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Ferias Internacionales'
,p_list_item_link_target=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'209,210'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263883911905029506)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Funcionarios / Ex-Funcionarios'
,p_list_item_link_target=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'211,212'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263884348054029506)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Concesiones Golfo de Papagayo'
,p_list_item_link_target=>'f?p=&APP_ID.:213:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'213,214'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263885161660029506)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Alquiler-Propiedades ICT (Locales)'
,p_list_item_link_target=>'f?p=&APP_ID.:215:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'215,216'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263886723171029507)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>unistr('Garant\00EDas de Cumplimiento')
,p_list_item_link_target=>'f?p=&APP_ID.:223:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263890353948029510)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>unistr('Garant\00EDas de Participaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:225:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263890755294029510)
,p_list_item_display_sequence=>401
,p_list_item_link_text=>'Otros Entes externos'
,p_list_item_link_target=>'f?p=&APP_ID.:217:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263881951639029505)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'217,218'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263888757568029508)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>'Agencias de Viajes No Recaudaras de impuestos'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263889164219029508)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Revisar Registro Agencia de Viajes'
,p_list_item_link_target=>'f?p=&APP_ID.:219:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263888757568029508)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263889574825029509)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>unistr('Inactivaci\00F3n Agencia de Viajes ')
,p_list_item_link_target=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263888757568029508)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263893929475029512)
,p_list_item_display_sequence=>481
,p_list_item_link_text=>unistr('Actualizaci\00F3n Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:ANRI:'
,p_parent_list_item_id=>wwv_flow_api.id(263888757568029508)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263894314908029512)
,p_list_item_display_sequence=>491
,p_list_item_link_text=>'Puestos Fronterizos'
,p_list_item_link_target=>'f?p=&APP_ID.:233:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'233,234'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263894741053029512)
,p_list_item_display_sequence=>492
,p_list_item_link_text=>unistr('Ch\00E1rter Ocasional Terrestre')
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263909147477029519)
,p_list_item_display_sequence=>811
,p_list_item_link_text=>unistr('Solicitud de Usuario y Contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:243:&SESSION.::&DEBUG.::P243_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263894741053029512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'243'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263909951818029520)
,p_list_item_display_sequence=>831
,p_list_item_link_text=>unistr('Declaraci\00F3n Jurada Pendiente')
,p_list_item_link_target=>'f?p=&APP_ID.:244:&SESSION.::&DEBUG.::P244_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263894741053029512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'244'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263910327264029520)
,p_list_item_display_sequence=>841
,p_list_item_link_text=>'Cartas al Registro Nacional'
,p_list_item_link_target=>'f?p=&APP_ID.:248:&SESSION.::&DEBUG.::P248_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263894741053029512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'248'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263912346379029521)
,p_list_item_display_sequence=>891
,p_list_item_link_text=>unistr('Actualizaci\00F3n de datos COT')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:COT:'
,p_parent_list_item_id=>wwv_flow_api.id(263894741053029512)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'250'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263895121511029512)
,p_list_item_display_sequence=>493
,p_list_item_link_text=>unistr('Gesti\00F3n Tr\00E1mite Terrestre Regular')
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263915168711029522)
,p_list_item_display_sequence=>971
,p_list_item_link_text=>unistr('Declaraci\00F3n Jurada Pendiente')
,p_list_item_link_target=>'f?p=&APP_ID.:244:&SESSION.::&DEBUG.::P244_TIPO_CONTRIBUYENTE:4:'
,p_parent_list_item_id=>wwv_flow_api.id(263895121511029512)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263915563894029523)
,p_list_item_display_sequence=>981
,p_list_item_link_text=>'Cartas al Registro Nacional'
,p_list_item_link_target=>'f?p=&APP_ID.:248:&SESSION.::&DEBUG.::P248_TIPO_CONTRIBUYENTE:4:'
,p_parent_list_item_id=>wwv_flow_api.id(263895121511029512)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263915916785029523)
,p_list_item_display_sequence=>991
,p_list_item_link_text=>unistr('Actualizaci\00F3n de datos TTR')
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_TIPO_INSCRIPCION:ITTR:'
,p_parent_list_item_id=>wwv_flow_api.id(263895121511029512)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263904771086029517)
,p_list_item_display_sequence=>701
,p_list_item_link_text=>'Actualizaciones Pendientes'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263891918315029511)
,p_list_item_display_sequence=>431
,p_list_item_link_text=>'Registro o cambio de apoderados'
,p_list_item_link_target=>'f?p=&APP_ID.:231:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263904771086029517)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'231'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263904358013029517)
,p_list_item_display_sequence=>691
,p_list_item_link_text=>unistr('Actualizaci\00F3n Representante Legal')
,p_list_item_link_target=>'f?p=&APP_ID.:235:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263904771086029517)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'235,236'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263905104578029517)
,p_list_item_display_sequence=>711
,p_list_item_link_text=>unistr('Actualizaci\00F3n Tipo Impuesto')
,p_list_item_link_target=>'f?p=&APP_ID.:237:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263904771086029517)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'237,238'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263907116881029518)
,p_list_item_display_sequence=>761
,p_list_item_link_text=>unistr('Activaci\00F3n usuario externo')
,p_list_item_link_target=>'f?p=&APP_ID.:239:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'239'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263908319207029519)
,p_list_item_display_sequence=>791
,p_list_item_link_text=>'Carga Documentos'
,p_list_item_link_target=>'f?p=&APP_ID.:152:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'152'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263918311335029524)
,p_list_item_display_sequence=>1051
,p_list_item_link_text=>unistr('Envi\00F3 de contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:251:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263876376633029502)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'251'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Reportes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263879135549029504)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Reporte Movimientos Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'300'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263879586800029504)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Reporte Movimientos No Contribuyente'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'301'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263892752012029511)
,p_list_item_display_sequence=>451
,p_list_item_link_text=>'Inscripciones por estado'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'302'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263893188940029511)
,p_list_item_display_sequence=>452
,p_list_item_link_text=>'Des-inscripciones por estado'
,p_list_item_link_target=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'304'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263893570529029512)
,p_list_item_display_sequence=>461
,p_list_item_link_text=>unistr('Envi\00F3 correos usuarios externos')
,p_list_item_link_target=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'303'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263903953847029517)
,p_list_item_display_sequence=>681
,p_list_item_link_text=>unistr('Creaci\00F3n de usuarios externos')
,p_list_item_link_target=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'305'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_display_sequence=>911
,p_list_item_link_text=>unistr('Ch\00E1rter Ocasional Terrestre')
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263912706605029521)
,p_list_item_display_sequence=>901
,p_list_item_link_text=>'Reporte por entidad y id deudor'
,p_list_item_link_target=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.::P306_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'306'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263913596860029522)
,p_list_item_display_sequence=>921
,p_list_item_link_text=>'Reporte cuenta por cobrar generadas'
,p_list_item_link_target=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.::P307_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'307,308'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263913996784029522)
,p_list_item_display_sequence=>931
,p_list_item_link_text=>'Reporte por numero de oficio enviado al RN'
,p_list_item_link_target=>'f?p=&APP_ID.:309:&SESSION.::&DEBUG.::P309_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'309'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263914349499029522)
,p_list_item_display_sequence=>941
,p_list_item_link_text=>'Reporte notificaciones efectuadas al RN'
,p_list_item_link_target=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.::P312_TIPO_CONTRIBUYENTE:8:'
,p_parent_list_item_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'312'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263914784224029522)
,p_list_item_display_sequence=>951
,p_list_item_link_text=>'Reporte Puesto Fronterizo'
,p_list_item_link_target=>'f?p=&APP_ID.:313:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263913122822029521)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'313'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263916372833029523)
,p_list_item_display_sequence=>1001
,p_list_item_link_text=>unistr('Tr\00E1mite Terrestre Regular')
,p_parent_list_item_id=>wwv_flow_api.id(263877168708029503)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263916705229029523)
,p_list_item_display_sequence=>1011
,p_list_item_link_text=>'Reporte cuenta por cobrar generadas'
,p_list_item_link_target=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.::P307_TIPO_CONTRIBUYENTE:17:'
,p_parent_list_item_id=>wwv_flow_api.id(263916372833029523)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263917189172029523)
,p_list_item_display_sequence=>1021
,p_list_item_link_text=>'Reporte por numero de oficio enviado al RN'
,p_list_item_link_target=>'f?p=&APP_ID.:309:&SESSION.::&DEBUG.::P309_TIPO_CONTRIBUYENTE:17:'
,p_parent_list_item_id=>wwv_flow_api.id(263916372833029523)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263917597243029524)
,p_list_item_display_sequence=>1031
,p_list_item_link_text=>unistr('Reporte por n\00FAmero de tr\00E1mite')
,p_list_item_link_target=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.::P306_TIPO_CONTRIBUYENTE:17:'
,p_parent_list_item_id=>wwv_flow_api.id(263916372833029523)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263917946794029524)
,p_list_item_display_sequence=>1041
,p_list_item_link_text=>'Reporte notificaciones efectuadas al RN'
,p_list_item_link_target=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.::P312_TIPO_CONTRIBUYENTE:17:'
,p_parent_list_item_id=>wwv_flow_api.id(263916372833029523)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263880350563029504)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Consultas'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Bit\00E1cora par\00E1metros ')
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(263880350563029504)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263881133784029505)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Venta')
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'400'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263882383806029505)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Tel\00E9fono')
,p_list_item_link_target=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'401'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263882750215029505)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Requisito ')
,p_list_item_link_target=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263884781671029506)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Modalidad')
,p_list_item_link_target=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'403'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263885501440029507)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Apoderado')
,p_list_item_link_target=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'404'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263885985963029507)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Identificaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'405'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263886393329029507)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Puesto Fronterizo')
,p_list_item_link_target=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'406'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263887197672029507)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'407'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263887549173029508)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Ente')
,p_list_item_link_target=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263887997757029508)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Local')
,p_list_item_link_target=>'f?p=&APP_ID.:409:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'409'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263888338642029508)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Empleado')
,p_list_item_link_target=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'410'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263895535432029513)
,p_list_item_display_sequence=>501
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Correo')
,p_list_item_link_target=>'f?p=&APP_ID.:411:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'411'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263895946454029513)
,p_list_item_display_sequence=>511
,p_list_item_link_text=>unistr('Bit\00E1cora encargado correos')
,p_list_item_link_target=>'f?p=&APP_ID.:412:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'412'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263896343960029513)
,p_list_item_display_sequence=>521
,p_list_item_link_text=>unistr('Bit\00E1cora tipo solicitud')
,p_list_item_link_target=>'f?p=&APP_ID.:413:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'413'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263903579174029517)
,p_list_item_display_sequence=>671
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Recomendaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:441:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'441'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263905961569029518)
,p_list_item_display_sequence=>731
,p_list_item_link_text=>unistr('Bit\00E1cora Tipo Noticia')
,p_list_item_link_target=>'f?p=&APP_ID.:442:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'442'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263906741553029518)
,p_list_item_display_sequence=>751
,p_list_item_link_text=>unistr('Bit\00E1cora Noticias SIT')
,p_list_item_link_target=>'f?p=&APP_ID.:443:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'443'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263910767506029520)
,p_list_item_display_sequence=>851
,p_list_item_link_text=>unistr('Bit\00E1cora Oficina Regional RN')
,p_list_item_link_target=>'f?p=&APP_ID.:452:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'452'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263911547352029521)
,p_list_item_display_sequence=>871
,p_list_item_link_text=>unistr('Bit\00E1cora Roles Sit')
,p_list_item_link_target=>'f?p=&APP_ID.:454:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'454'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263911944975029521)
,p_list_item_display_sequence=>881
,p_list_item_link_text=>unistr('Bit\00E1cora Roles Usuario')
,p_list_item_link_target=>'f?p=&APP_ID.:455:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263880776611029504)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'455'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_display_sequence=>531
,p_list_item_link_text=>unistr('Bit\00E1coras Procesos')
,p_parent_list_item_id=>wwv_flow_api.id(263880350563029504)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263897147927029513)
,p_list_item_display_sequence=>541
,p_list_item_link_text=>unistr('Bit\00E1cora inscripci\00F3n regular')
,p_list_item_link_target=>'f?p=&APP_ID.:414:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'414'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263897545166029513)
,p_list_item_display_sequence=>542
,p_list_item_link_text=>unistr('Bit\00E1cora Inscripci\00F3n Vuelos Ch\00E1rter')
,p_list_item_link_target=>'f?p=&APP_ID.:416:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'416'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263897948353029514)
,p_list_item_display_sequence=>543
,p_list_item_link_text=>unistr('Bit\00E1cora Inscripci\00F3n Agencia no recaudadora de impuestos')
,p_list_item_link_target=>'f?p=&APP_ID.:417:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'417'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263898394468029514)
,p_list_item_display_sequence=>551
,p_list_item_link_text=>unistr('Bit\00E1cora Maestro Contribuyente')
,p_list_item_link_target=>'f?p=&APP_ID.:415:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'415'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263898776160029514)
,p_list_item_display_sequence=>561
,p_list_item_link_text=>unistr('Bit\00E1cora Hoteles')
,p_list_item_link_target=>'f?p=&APP_ID.:418:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'418'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263899162728029514)
,p_list_item_display_sequence=>571
,p_list_item_link_text=>unistr('Bit\00E1cora Puesto Fronterizo')
,p_list_item_link_target=>'f?p=&APP_ID.:419:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'419'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263899517928029514)
,p_list_item_display_sequence=>581
,p_list_item_link_text=>unistr('Bit\00E1cora Ferias Internacionales')
,p_list_item_link_target=>'f?p=&APP_ID.:420:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'420'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263899900030029515)
,p_list_item_display_sequence=>591
,p_list_item_link_text=>unistr('Bit\00E1cora Funcionarios / Ex Funcionarios')
,p_list_item_link_target=>'f?p=&APP_ID.:421:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'421'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263900317790029515)
,p_list_item_display_sequence=>601
,p_list_item_link_text=>unistr('Bit\00E1cora Concesiones Golfo de Papagayo')
,p_list_item_link_target=>'f?p=&APP_ID.:422:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'422'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263900774806029515)
,p_list_item_display_sequence=>611
,p_list_item_link_text=>unistr('Bit\00E1cora Alquileres Propiedades ICT (Locales)')
,p_list_item_link_target=>'f?p=&APP_ID.:423:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'423'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263901170730029515)
,p_list_item_display_sequence=>621
,p_list_item_link_text=>unistr('Bit\00E1cora Garant\00EDas de cumplimiento')
,p_list_item_link_target=>'f?p=&APP_ID.:424:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'424'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263901553166029516)
,p_list_item_display_sequence=>631
,p_list_item_link_text=>unistr('Bit\00E1cora Garant\00EDas de participaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:425:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'425'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263901909563029516)
,p_list_item_display_sequence=>641
,p_list_item_link_text=>unistr('Bit\00E1cora Otros Entes Externos')
,p_list_item_link_target=>'f?p=&APP_ID.:426:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'426'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263907594549029519)
,p_list_item_display_sequence=>771
,p_list_item_link_text=>unistr('Bit\00E1cora Comprueba Requisitos')
,p_list_item_link_target=>'f?p=&APP_ID.:444:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'444'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263907994311029519)
,p_list_item_display_sequence=>781
,p_list_item_link_text=>unistr('Bit\00E1cora Solicitud Des-inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:445:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'445'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(263911172917029520)
,p_list_item_display_sequence=>861
,p_list_item_link_text=>unistr('Bit\00E1cora Carga Documentos')
,p_list_item_link_target=>'f?p=&APP_ID.:453:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(263896742913029513)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'453'
);
wwv_flow_api.component_end;
end;
/
